#!/bin/bash
set -o errexit -o nounset
addToDrat(){
  PKG_REPO=$PWD
  GH_REPO="@github.com/PredictiveEcology/SpaDES.git"
  FULL_REPO="https://$GH_TOKEN$GH_REPO"

  mkdir ../../gh-pages
  cd ../../gh-pages
  git clone --depth=50 --branch=gh-pages $FULL_REPO SpaDES

  cd SpaDES
  git checkout gh-pages
  git config user.name "PredictiveEcology-travis"
  git config user.email "travis"

  Rscript -e "drat::insertPackage('$PKG_REPO/$PKG_TARBALL', \
    repodir = '.', \
    commit='Travis update: build $TRAVIS_BUILD_NUMBER')"
  git push 2> /tmp/err.txt

  cd $PKGDIR
}
addToDrat
