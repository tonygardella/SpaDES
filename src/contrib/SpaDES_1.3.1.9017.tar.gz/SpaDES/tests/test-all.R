library(testthat)
test_check("SpaDES")
